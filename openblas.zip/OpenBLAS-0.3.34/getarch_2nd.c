/***************************************************************************
 * Copyright (c) 2025, The OpenBLAS Project
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in
 * the documentation and/or other materials provided with the
 * distribution.
 * 3. Neither the name of the OpenBLAS project nor the names of
 * its contributors may be used to endorse or promote products
 * derived from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE OPENBLAS PROJECT OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 * *****************************************************************************/

#include <stdio.h>
#ifndef BUILD_KERNEL
#include "config.h"
#else
#include "config_kernel.h"
#endif
#if (defined(__WIN32__) || defined(__WIN64__) || defined(__CYGWIN32__) || defined(__CYGWIN64__) || defined(_WIN32) || defined(_WIN64)) && defined(__64BIT__)
typedef long long BLASLONG;
typedef unsigned long long BLASULONG;
#else
typedef long BLASLONG;
typedef unsigned long BLASULONG;
#endif

#include "param.h"

int main(int argc, char **argv) {

  if ( (argc <= 1) || ((argc >= 2) && (*argv[1] == '0'))) {
    printf("BGEMM_UNROLL_M=%d\n", BGEMM_DEFAULT_UNROLL_M);
    printf("BGEMM_UNROLL_N=%d\n", BGEMM_DEFAULT_UNROLL_N);
    printf("BGEMM_UNROLL_M=%d\n", BGEMM_DEFAULT_UNROLL_M);
    printf("BGEMM_UNROLL_N=%d\n", BGEMM_DEFAULT_UNROLL_N);
    printf("SBGEMM_UNROLL_M=%d\n", SBGEMM_DEFAULT_UNROLL_M);
    printf("SBGEMM_UNROLL_N=%d\n", SBGEMM_DEFAULT_UNROLL_N);
    printf("SHGEMM_UNROLL_M=%d\n", SHGEMM_DEFAULT_UNROLL_M);
    printf("SHGEMM_UNROLL_N=%d\n", SHGEMM_DEFAULT_UNROLL_N);
    printf("SGEMM_UNROLL_M=%d\n", SGEMM_DEFAULT_UNROLL_M);
    printf("SGEMM_UNROLL_N=%d\n", SGEMM_DEFAULT_UNROLL_N);
    printf("DGEMM_UNROLL_M=%d\n", DGEMM_DEFAULT_UNROLL_M);
    printf("DGEMM_UNROLL_N=%d\n", DGEMM_DEFAULT_UNROLL_N);
    printf("QGEMM_UNROLL_M=%d\n", QGEMM_DEFAULT_UNROLL_M);
    printf("QGEMM_UNROLL_N=%d\n", QGEMM_DEFAULT_UNROLL_N);

    printf("CGEMM_UNROLL_M=%d\n", CGEMM_DEFAULT_UNROLL_M);
    printf("CGEMM_UNROLL_N=%d\n", CGEMM_DEFAULT_UNROLL_N);
    printf("ZGEMM_UNROLL_M=%d\n", ZGEMM_DEFAULT_UNROLL_M);
    printf("ZGEMM_UNROLL_N=%d\n", ZGEMM_DEFAULT_UNROLL_N);
    printf("XGEMM_UNROLL_M=%d\n", XGEMM_DEFAULT_UNROLL_M);
    printf("XGEMM_UNROLL_N=%d\n", XGEMM_DEFAULT_UNROLL_N);

#ifdef CGEMM3M_DEFAULT_UNROLL_M
    printf("CGEMM3M_UNROLL_M=%d\n", CGEMM3M_DEFAULT_UNROLL_M);
#else
    printf("CGEMM3M_UNROLL_M=%d\n", SGEMM_DEFAULT_UNROLL_M);
#endif

#ifdef CGEMM3M_DEFAULT_UNROLL_N
    printf("CGEMM3M_UNROLL_N=%d\n", CGEMM3M_DEFAULT_UNROLL_N);
#else
    printf("CGEMM3M_UNROLL_N=%d\n", SGEMM_DEFAULT_UNROLL_N);
#endif

#ifdef ZGEMM3M_DEFAULT_UNROLL_M
    printf("ZGEMM3M_UNROLL_M=%d\n", ZGEMM3M_DEFAULT_UNROLL_M);
#else
    printf("ZGEMM3M_UNROLL_M=%d\n", DGEMM_DEFAULT_UNROLL_M);
#endif

#ifdef ZGEMM3M_DEFAULT_UNROLL_N
    printf("ZGEMM3M_UNROLL_N=%d\n", ZGEMM3M_DEFAULT_UNROLL_N);
#else
    printf("ZGEMM3M_UNROLL_N=%d\n", DGEMM_DEFAULT_UNROLL_N);
#endif

#ifdef XGEMM3M_DEFAULT_UNROLL_M
    printf("XGEMM3M_UNROLL_M=%d\n", ZGEMM3M_DEFAULT_UNROLL_M);
#else
    printf("XGEMM3M_UNROLL_M=%d\n", QGEMM_DEFAULT_UNROLL_M);
#endif

#ifdef XGEMM3M_DEFAULT_UNROLL_N
    printf("XGEMM3M_UNROLL_N=%d\n", ZGEMM3M_DEFAULT_UNROLL_N);
#else
    printf("XGEMM3M_UNROLL_N=%d\n", QGEMM_DEFAULT_UNROLL_N);
#endif


  }


  if ((argc >= 2) && (*argv[1] == '1')) {

#if defined(ARCH_X86) || defined(ARCH_X86_64)
    printf("#define SLOCAL_BUFFER_SIZE\t%ld\n", (SGEMM_DEFAULT_Q * SGEMM_DEFAULT_UNROLL_N * 4 * 1 *  sizeof(float)));
    printf("#define DLOCAL_BUFFER_SIZE\t%ld\n", (DGEMM_DEFAULT_Q * DGEMM_DEFAULT_UNROLL_N * 2 * 1 *  sizeof(double)));
    printf("#define CLOCAL_BUFFER_SIZE\t%ld\n", (CGEMM_DEFAULT_Q * CGEMM_DEFAULT_UNROLL_N * 4 * 2 *  sizeof(float)));
    printf("#define ZLOCAL_BUFFER_SIZE\t%ld\n", (ZGEMM_DEFAULT_Q * ZGEMM_DEFAULT_UNROLL_N * 2 * 2 *  sizeof(double)));
#endif

#ifdef USE64BITINT
	printf("#define USE64BITINT\n");
#endif
	printf("#define GEMM_MULTITHREAD_THRESHOLD\t%ld\n", (long int)GEMM_MULTITHREAD_THRESHOLD);
  }

  return 0;
}
